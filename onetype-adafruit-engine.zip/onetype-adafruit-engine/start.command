#!/bin/sh
cd "$(dirname "$0")"
sh run.sh
